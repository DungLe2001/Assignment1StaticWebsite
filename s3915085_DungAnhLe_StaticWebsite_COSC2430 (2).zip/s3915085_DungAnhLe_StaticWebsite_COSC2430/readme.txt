Hello sir, my name is Dung Le (s3915085)

I will have a bried introduction and guidance for you about my online bookstore website.

First in the file, run with homepage file with google chrome first, and then in the home page, click the title of the type the books
it will move you to the category page where you can click on the image of the books and it will show you the details of that book.

this is the URL link to my website: https://dungle2001.github.io/Assignment1StaticWebsite/

Thank you for reading!
